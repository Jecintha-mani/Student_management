CREATE DATABASE STUDENT_MANAGEMENT;
drop database student_management;
USE STUDENT_MANAGEMENT;

CREATE TABLE student (
    id INT PRIMARY KEY,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    gender VARCHAR(10),
    city VARCHAR(50),
    state VARCHAR(50),
    mobile_number VARCHAR(15),
    email_id VARCHAR(100) UNIQUE,
    course_id INT,
    course_name VARCHAR(50),
    enrollment_date DATE,
    course_type VARCHAR(20),
    grade VARCHAR(5)
);

SELECT * FROM student;
INSERT INTO STUDENT (id,first_name,last_name,gender,city,state,mobile_number,email_id,course_id,course_name,enrollment_date,course_type,grade)VALUES
(?,?,?,?,?,?,?,?,?,?,?,?,?);
SELECT * FROM STUDENT where ID=?;
UPDATE STUDENT SET course_name = ? WHERE id = ?;
DELETE FROM STUDENT WHERE id = ?;
SELECT * FROM STUDENT WHERE email_id = ? AND enrollment_date = ?