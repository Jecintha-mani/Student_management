System.out.println("***********************************************************");
INSERT INTO student
(id, first_name, last_name, gender, city, state, mobile_number, email_id, course_id, course_name, enrollment_date, course_type, grade)
VALUES
(1,'Karthik','K','M','Chennai','Tamil Nadu','9876543210','karthik1@gmail.com',101,'Java','2026-01-10','ONLINE','A'),
(2,'Arun','Kumar','M','Coimbatore','Tamil Nadu','9876543211','arun2@gmail.com',102,'Python','2026-01-12','OFFLINE','B'),
(3,'Priya','R','F','Madurai','Tamil Nadu','9876543212','priya3@gmail.com',103,'DBMS','2026-01-15','ONLINE','A'),
(4,'Vignesh','S','M','Salem','Tamil Nadu','9876543213','vignesh4@gmail.com',104,'Data Science','2026-01-18','OFFLINE','A'),
(5,'Divya','M','F','Trichy','Tamil Nadu','9876543214','divya5@gmail.com',105,'Web Development','2026-01-20','ONLINE','B'),
(6,'Rahul','P','M','Erode','Tamil Nadu','9876543215','rahul6@gmail.com',106,'AI','2026-01-22','OFFLINE','A'),
(7,'Sneha','T','F','Vellore','Tamil Nadu','9876543216','sneha7@gmail.com',107,'Machine Learning','2026-01-25','ONLINE','A'),
(8,'Ajith','K','M','Tirunelveli','Tamil Nadu','9876543217','ajith8@gmail.com',108,'Cloud Computing','2026-01-28','OFFLINE','B'),
(9,'Nisha','L','F','Chennai','Tamil Nadu','9876543218','nisha9@gmail.com',109,'Cyber Security','2026-02-01','ONLINE','A'),
(10,'Surya','V','M','Thanjavur','Tamil Nadu','9876543219','surya10@gmail.com',110,'Full Stack','2026-02-03','OFFLINE','A'),
(11,'Hari','M','M','Chennai','Tamil Nadu','9876543220','hari11@gmail.com',111,'Java','2026-02-05','ONLINE','B'),
(12,'Keerthana','S','F','Madurai','Tamil Nadu','9876543221','keerthana12@gmail.com',112,'Python','2026-02-08','OFFLINE','A'),
(13,'Gokul','R','M','Salem','Tamil Nadu','9876543222','gokul13@gmail.com',113,'DBMS','2026-02-10','ONLINE','C'),
(14,'Anitha','P','F','Coimbatore','Tamil Nadu','9876543223','anitha14@gmail.com',114,'AI','2026-02-12','OFFLINE','A'),
(15,'Manoj','K','M','Trichy','Tamil Nadu','9876543224','manoj15@gmail.com',115,'Cloud Computing','2026-02-15','ONLINE','B'),
(16,'Pooja','R','F','Erode','Tamil Nadu','9876543225','pooja16@gmail.com',116,'Machine Learning','2026-02-18','OFFLINE','A'),
(17,'Sanjay','V','M','Vellore','Tamil Nadu','9876543226','sanjay17@gmail.com',117,'Cyber Security','2026-02-20','ONLINE','B'),
(18,'Meena','T','F','Thanjavur','Tamil Nadu','9876543227','meena18@gmail.com',118,'Data Science','2026-02-22','OFFLINE','A'),
(19,'Praveen','L','M','Tirunelveli','Tamil Nadu','9876543228','praveen19@gmail.com',119,'Web Development','2026-02-25','ONLINE','C'),
(20,'Kavya','N','F','Chennai','Tamil Nadu','9876543229','kavya20@gmail.com',120,'Full Stack','2026-02-28','OFFLINE','A');